import os
import shutil
import csv
from PIL import Image
from datetime import datetime
import pandas as pd

# Define source and output folders
source_folder = 'E:/et3_Company/problem 1/dairies'    #path to the folder contained images 
output_folder = 'E:/et3_Company/problem 1/Solution/images_data'  #path to the new folder which contains all images 
csv_output_folder = 'E:/et3_Company/problem 1/Solution/csv_output_folder' #path to the new folder which contains csv file

# Define valid image file extensions
image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp']

# Function to extract image metadata
def extract_image_metadata(src_path):
    # Extract the destination filename and create a new filename
    dst_filename = os.path.basename(src_path)
    new_filename = '-'.join(dst_filename.split('-')[1:])
    dst_path = os.path.join(output_folder, new_filename)
    
    # Move the image to the output folder with the new name
    shutil.move(src_path, dst_path)

    # Extract image metadata
    image_name = new_filename
    image_size = os.path.getsize(dst_path)
    last_modification_date = datetime.fromtimestamp(os.path.getmtime(dst_path))
    formatted_date = last_modification_date.strftime('%Y-%m-%d %H:%M:%S')

    return [image_name, image_size, formatted_date]

# Initialize a list to store image metadata
image_metadata = []

# Recursively gather all image files with valid extensions
allfiles = [os.path.join(root, file) for root, _, files in os.walk(source_folder) for file in files if os.path.splitext(file)[1].lower() in image_extensions]

# Create the destination directory if it doesn't exist
os.makedirs(output_folder, exist_ok=True)
os.makedirs(csv_output_folder, exist_ok=True)

# Iterate through image files, extract metadata, and move them
for src_path in allfiles:
    metadata = extract_image_metadata(src_path)
    image_metadata.append(metadata)

# Define the CSV header
csv_header = ["Image Name", "Image Size (bytes)", "Last Modification Date"]

# Define the CSV file path outside the output folder
csv_file = os.path.join(csv_output_folder, 'image_metadata_CSV.csv')

# Write metadata to a CSV file
with open(csv_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(csv_header)
    writer.writerows(image_metadata)

# Read the CSV file into a DataFrame
df = pd.read_csv(csv_file)

# Convert the DataFrame to an Excel file to be more organized
df.to_excel("E:/et3_Company/problem 1/Solution/csv_output_folder/image_metadata_Excel.xlsx", index=False) #path to new excel file 

print("Images are moved successfully to the 'images_data' folder.")
print("CSV file is created successfully inside the 'csv_output_folder' folder.")