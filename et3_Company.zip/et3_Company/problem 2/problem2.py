import json

# Step 1: path to read the text file
input_text_file = 'E:/et3_Company/problem 2/image1 (2).txt'
output_json_file = 'Solution.json'  #path to output file

with open(input_text_file, 'r') as file:
    text_lines = file.readlines()

# Step 2: Parse and format the data
annotations = []

for line in text_lines:
    values = line.strip().split()
    if len(values) == 5:
        x, y, width, height = map(float, values[1:])
        annotation = {
            "image_rotation": 0,
            "value": {
                "x": x,
                "y": y,
                "width": width,
                "height": height,
                "rotation": 0,
                "rectanglelabels": ["object"]
            }
        }
        annotations.append(annotation)

# Step 3: Create the JSON object
data = {
    "annotations": annotations,
    "data": {
        "image": "/data/upload/image1.jpg"
    }
}

# Step 4: Write the JSON to a file
with open(output_json_file, 'w') as json_file:
    json.dump(data, json_file, indent=4)

print(f"JSON file '{output_json_file}' created successfully.")
